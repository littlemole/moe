// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once


#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers

#include <crtdbg.h>

// if the following line fails, you have to add
// $JAVA_HOME/include and $JAVA_HOME/include/win32
// to your include directory.
#include <jni.h>

namespace jnitl {
	// must be called to initialize JNITL
	void jnitl_init(JNIEnv* env);
}