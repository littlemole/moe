var doc = moe.ActiveDoc;
if ( doc )
{
  var d = doc.Document;
  if ( d )
  {
	d.InsertColorDialog();
  }
}


