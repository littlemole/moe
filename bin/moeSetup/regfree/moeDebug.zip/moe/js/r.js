
moe.ShowForm( 
	   "forms\\regexp.html",
	   moe.left+225, moe.top+225, 450, 390,
	   6 );

