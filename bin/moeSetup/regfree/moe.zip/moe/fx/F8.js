if ( moe.ShowTreeView )
  moe.ShowTreeView = false;
else
  moe.ShowTreeView = true;

