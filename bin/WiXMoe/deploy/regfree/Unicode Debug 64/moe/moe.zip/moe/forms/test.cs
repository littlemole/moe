
public class Test
{

static int Main(string[] args)
{
System.Windows.Forms.MessageBox.Show("HU");
return 0;

}
};