
moe.Script.ShowHtmlForm( 
	   "\\forms\\prefs.html",
	   moe.View.left+225, moe.View.top+225, 450, 190,
	   6 );

