var doc = moe.ActiveDoc;
if ( doc )
{
	doc.Save();
}
