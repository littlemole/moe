
moe.ShowForm( 
	   "C:\\molib8\\test\\win_TEST\\xmoe\\forms\\prefs.html",
	   moe.left+225, moe.top+225, 450, 190,
	   6 );

