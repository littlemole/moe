
moe.Script.ShowHtmlForm( "\\doc\\index.html",moe.View.left+25,moe.View.top+25,700,450,5);

