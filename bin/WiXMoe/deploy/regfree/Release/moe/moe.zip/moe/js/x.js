
moe.Script.ShowHtmlForm( 
			  "\\forms\\xslt.html",
			  moe.View.left+250,moe.View.top+250,
			  440,249,2
		);

