if ( moe.View.ShowTreeView )
  moe.View.ShowTreeView = false;
else
  moe.View.ShowTreeView = true;

