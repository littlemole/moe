
moe.Script.ShowHtmlForm( 
	   "\\forms\\regexp.html",
	   moe.View.left+225, moe.View.top+225, 450, 390,
	   6 );

