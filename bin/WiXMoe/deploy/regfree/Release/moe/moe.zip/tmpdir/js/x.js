
moe.ShowForm( 
			  "C:\\molib8\\test\\win_TEST\\xmoe\\forms\\xslt.html",
			  moe.left+250,moe.top+250,
			  440,249,2
		);

