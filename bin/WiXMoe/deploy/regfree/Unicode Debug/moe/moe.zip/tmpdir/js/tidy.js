
moe.ShowForm( 
			  "forms\\tidy.html",
			  moe.left+250,moe.top+250,
			  440,235,2
		);

