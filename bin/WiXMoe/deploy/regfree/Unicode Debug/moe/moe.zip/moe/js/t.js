
moe.Script.ShowHtmlForm( 
			  "\\forms\\search.html",
			  moe.View.left+250,moe.View.top+250,
			  440,300,2
		);

