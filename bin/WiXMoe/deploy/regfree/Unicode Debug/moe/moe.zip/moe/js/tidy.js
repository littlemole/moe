
moe.Script.ShowHtmlForm( 
			  "\\forms\\tidy.html",
			  moe.View.left+250,moe.View.top+250,
			  440,235,2
		);

